#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>

void* descomprimirArchivo(void* argumento) {
    char* rutaArchivo = (char*)argumento;

    // Comando para descomprimir el archivo usando unrar
    char comando[512];
    snprintf(comando, sizeof(comando), "unrar x \"%s\"", rutaArchivo);

    // Ejecutar el comando
    int resultado = system(comando);

    if (resultado == 0) {
        printf("Archivo descomprimido exitosamente.\n");
    } else {
        printf("Error al descomprimir el archivo. Código de error: %d\n", resultado);
    }

    // Liberar memoria si es necesario
    free(argumento);

    return NULL;
}

int main() {
    // Ruta del archivo .rar
    const char* rutaArchivo = "/home/ramiro/Escritorio/archivo.rar";

    // Crear una copia dinámica de la ruta del archivo para pasar al hilo
    char* rutaArchivoCopia = strdup(rutaArchivo);
    if (rutaArchivoCopia == NULL) {
        perror("Error al asignar memoria para la ruta del archivo");
        return 1;
    }

    pthread_t hilo;

    // Crear un hilo para descomprimir el archivo
    int resultado = pthread_create(&hilo, NULL, descomprimirArchivo, (void*)rutaArchivoCopia);
    if (resultado != 0) {
        fprintf(stderr, "Error al crear el hilo. Código de error: %d\n", resultado);
        free(rutaArchivoCopia);
        return 1;
    }

    // Esperar a que el hilo termine
    pthread_join(hilo, NULL);

    return 0;
}

